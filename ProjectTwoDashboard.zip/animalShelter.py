from pymongo import MongoClient
import pymongo
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

# Initialization
    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        self.client = MongoClient('mongodb://%s:%s@localhost:30163' % (username, password))
        self.database = self.client['AAC'] # Connect to the proper database that houses the "animals" collection
        return print ("Connection Successful")

# Creation
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data)  # Insert data using a dictionary data type
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            return False
# Read
    def read(self, key):
        if key is not None:
            output = self.database.animals.find(key, {"_id":False}) # Find entry & return cursor object
            return output
        else:
            raise Exception("No entry found")

# Update
    def update(self, key, data):
        if key and data is not None:
            updated = self.database.animals.update_one(key, data) # Update first document found
            print("Documents Updated:", + updated.modified_count)
        else:
            raise Exception("Invalid input")
# Update Many
    def updateAll(self, key, data):
        if key and data is not None:
            updated = self.database.animals.update_many(key, data) # Update all documents with value pair
            print("Documents Updated:", + updated.modified_count)
        else:
            raise Exception("Invalid input")
        
# Delete
    def delete(self, key):
        if key is not None:
            deleted = self.database.animals.delete_one(key) # Delete first document found
            print("Document Deleted")
        else:
            raise Exception("No entry found")
# Delete Many
    def deleteAll(self, key):
        if key is not None:
            deleted = self.database.animals.delete_many(key) # Delete all documents with value pair
            print("Documents Deleted:", + deleted.deleted_count)
        else:
            raise Exception("No entry found")